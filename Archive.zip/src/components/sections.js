import React from "react";

const Sections= () => {
    return (
        <React.Fragment>
            <h1>Sections</h1>
        </React.Fragment>
    )
}

export default Sections;