import React from "react";

const List= () => {
    return (
        <React.Fragment>
            <h1>List</h1>
        </React.Fragment>
    )
}

export default List;