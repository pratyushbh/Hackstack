import React from "react";

const NGO_page= () => {
    return (
        <React.Fragment>
            <div className="Page_details">
                <h1>//Title</h1>
                <p>//Image</p>
                <p>//description</p>
                <p>//problens solved</p>
            </div>
        </React.Fragment>
    )
}

export default NGO_page;